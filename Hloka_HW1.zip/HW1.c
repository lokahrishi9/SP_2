#include<stdio.h>
#include<string.h>
#include<stdbool.h>
#include<stdlib.h>
#define MAXCHAR 1000
typedef struct
{
	char first_name[100];
	char last_name[100];
	char major[100];
	char degree[100];
	double gpa;
	int credithours;
	char TA[50];
	char advisor[100];
	
}Data;

void degreeFunction(Data data[],int a) 
{
	printf("question 1 -------------------------------------------------------------------------------------------------\n");
	printf("The different degrees do we have are : \n");
	int unique_count=0;
  	int check;
  	int j=0,i=0;
  for (i = 0; i < a-2; i++) {
    for (j = i + 1; j < a-2; j++)
        if (strcmp(data[i].degree, data[j].degree) == 0 )
            break;
    if (j == a-2)
    {
	
        unique_count++;
        printf(" %d : %s \n",unique_count,data[i].degree);
    }
}
printf(" Total no of degrees are %d \n",unique_count);
        
}

void highestGPAFunction(Data data[],int a) 
{
	printf("question 2 -------------------------------------------------------------------------------------------------\n");
double  first, second, third;
 
   int i=0,j=0;
    if (a-2 < 3) 
	{
        printf(" we should have atleast three records  ");
        return;
    }
 
    third = first = second = 0;
    for (i = 0; i < a-2; i++) 
	{
        if (data[i].gpa > first) 
		{
            third = second;
            second = first;
            first = data[i].gpa;
        }
 
        else if (data[i].gpa > second) 
		{
            third = second;
            second = data[i].gpa;
        }
 
        else if (data[i].gpa > third)
            third = data[i].gpa;
    }
    
    printf("\n Full name of the 3 students who have the highest GPA \n ");
    for (i = 0; i < a-2; i++)
    {
		if(data[i].gpa==first || data[i].gpa==second || data[i].gpa==third )
		{
			
    	printf(" \n  highest GPA  for the candidate %s %s of gpa  %.2f \n", data[i].first_name,data[i].last_name, data[i].gpa);
  		printf("\n");
		}	
	}
}

void averageCreditHoursFunction(Data data[],int a) 
{
	printf("question 3 -------------------------------------------------------------------------------------------------\n");
	int i=0,j=0;
	double average=0;	
	for (i = 0; i < a-2; i++)
    {
		average=data[i].credithours+average;
	}
	printf("\n Total credit hours are %lf \n",average);
	average=average/a-2;
	printf("\n Average credit hours of the college are : %lf \n",average);
	
}
 void averageGPAFunction(Data data[],int a) 
{
	printf("question 4 -------------------------------------------------------------------------------------------------\n");
	
	int counter=0,i=0;
	double average=0;
	for (i = 0; i < a-2; i++)
    {
		if (strcmp(data[i].major, "Computer Science") == 0 )
		{
		average=data[i].gpa+average;
		//printf("%lf ",data[i].gpa);
		counter++;	
		}
	
	}
	printf("\n Total gpa of computer Science are %lf \n",average);
	average=average/counter;
	printf("\n Average GPA of the students whose department is Computer Science %lf \n",average);
 
}

void listOfDepartmentsFunction(Data data[],int a) 
{	printf("question 5 -------------------------------------------------------------------------------------------------\n");
	
	int i,j;
	char *str_arr[100] ;
	int unique_count1=0;
	int l;
	printf("\n List of departments along with the total number of advisors.\n");
	for (i = 0; i < a-2; i++) 
	{
    for (j = i + 1; j < a-2; j++)
        if (strcmp(data[i].major, data[j].major) == 0 )
            break;
    	if (j == a-2)
    	{	
			l=strlen(data[i].major);
			//printf("%d",l);
			str_arr[unique_count1]=(char *)malloc(sizeof(char)*(l+1));
    		//printf("%s \n",data[i].major);
    		strcpy(str_arr[unique_count1],data[i].major);
    		unique_count1++;
    	}
	}
	int k,counter1=0;
	for(k=0;k<unique_count1;k++)
	{
	//printf("%s -------------\n",str_arr[k]);
		counter1=0;
		for (i = 0; i < a-2; i++) 
		{
			if(strcmp(data[i].major, str_arr[k]) == 0)
			{			
	    		for (j = i + 1; j < a-2; j++)
		    	if(strcmp(data[j].major, str_arr[k]) == 0 )
		    	{
				//printf("%s %s %s %s\n",data[i].major,data[j].major,data[i].advisor,data[j].advisor);
		        	if (strcmp(data[i].advisor, data[j].advisor) == 0 )
		            	break;
				}
			
		   		 if (j == a-2)
		    	{
			
		        counter1++;
		        //printf("%s\n",data[i].advisor);
		    	}
			}
		}			
printf("\n %s -------------%d \n ",str_arr[k],counter1);
}
}

int main(void)
{
	FILE *file;
	file =fopen("students_dataset.csv","r");
    if(file==NULL)
    {
    	printf("error in file name");
    	return 1;
	}
	Data data[100];
	int ch;
	int read=0;
	int records=0;
	int a=0;
	char line[100];
	do
	{
		read=fscanf(file,"%99[^,],%99[^,],%99[^,],%99[^,],%lf,%d,%99[^,],%99[^,\n]",
		data[records].first_name,
		data[records].last_name,
		data[records].major,
		data[records].degree,
		&data[records].gpa,
		&data[records].credithours,
		data[records].TA,
		data[records].advisor
		);
		

	if (read == 8)
	{  
	records++;
	}
	if (read != 8 && a!=0 &&!feof(file))
    {
      printf("File format incorrect.\n");
    }
    
    if (ferror(file))
    {
      printf("Error reading file.\n");
      return 1;
    }
	a++;
	}while(fgets(line,sizeof(line),file));
	
	fclose(file);
	
	degreeFunction(data,a);
	highestGPAFunction(data,a);
	averageCreditHoursFunction(data,a);
	averageGPAFunction(data,a);
	listOfDepartmentsFunction(data,a);
	

}

